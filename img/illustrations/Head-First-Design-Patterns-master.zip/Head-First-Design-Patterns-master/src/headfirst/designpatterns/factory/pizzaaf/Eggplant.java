package headfirst.designpatterns.factory.pizzaaf;

public class Eggplant implements Veggies {

	public String toString() {
		return "Eggplant";
	}
}
