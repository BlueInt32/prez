package headfirst.designpatterns.factory.pizzaaf;

public interface Veggies {
	public String toString();
}
