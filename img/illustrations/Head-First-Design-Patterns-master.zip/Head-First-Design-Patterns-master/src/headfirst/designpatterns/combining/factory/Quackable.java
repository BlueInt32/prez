package headfirst.designpatterns.combining.factory;

public interface Quackable {
	public void quack();
}
