package headfirst.designpatterns.command.remote;

public class NoCommand implements Command {
	public void execute() { }
}
