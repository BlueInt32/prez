package headfirst.designpatterns.command.simpleremoteWL;

public interface Command {
	public void execute();
}
